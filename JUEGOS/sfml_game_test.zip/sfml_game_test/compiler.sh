#!/bin/bash
g++ -c main.cpp
g++ main.o -o bin/test -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -lsfml-network
./bin/test
